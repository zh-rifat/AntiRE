import subprocess

from cryptography import fernet
import os
import base64
import base45
import json
from random import randint
import requests

def read_key():
    return str(open("data/profile.key.dat").read())

    user=open("data/profile/user.dat",'rb').read()
    uid=base64.b64decode(base45.b45decode(str(user,'utf-8')).decode()).decode()
    return requests.get(f"http://localhost:8779/api/getkey/{uid}").json()['key']


def decrypt_file(filename,key):
    file=open(filename,"rb")
    filedata=bytearray(file.read())
    key=bytes(key,'utf-8')
    decrypted_data=bytearray()
    for i in range(len(filedata)):
        decrypted_data.append((filedata[i]-key[i%len(key)])%256)
    file.close()
    # return decrypted_data
    dir="data/tmp"
    if not os.path.isdir(dir):
        os.mkdir('data/tmp')
    file=open("data/tmp/UGFyYWRveGljYWxIYWNrZXJTcXVhZA.exe","wb")
    file.write(decrypted_data)
    file.close()


# print(read_key())
# encrypt_file("v3.exe",read_key())
decrypt_file("data/phs_smtp_tool.dat",read_key())
# file=decrypt_file("data.txt",read_key())
# os.startfile(bytearray.decode(decrypt_file("p1.exe",read_key()),'hex'))
# exec(file)

# try:
#     p=subprocess.Popen("C:\.Trash-0\decrypted.bin")
#     p.wait()
#     print("exiting")
#     os.remove("decrypted.exe")
#
# except :
#     os.remove("decrypted.exe")
#     input()
#     exit()

# file=open("data.txt","r")
#
# print(file.read())
